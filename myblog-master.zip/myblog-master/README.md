# Java SSM个人博客系统
* 使用Spring、SpringMVC、Mybatis框架  
* 基于shiro进行权限管理  
* 完整的登录、发表、修改、删除功能

 在线演示地址：https://countryroads.xin

 项目完整记录：https://blog.csdn.net/van_brilliant/article/details/79601662
